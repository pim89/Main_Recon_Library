classdef ChunkParsUsr < ChunkPars
   % User Defined Chunk Parameter
    properties       
        % Add your own parameter here        
    end
    
    methods
        % Add your own functions here
    end
end

