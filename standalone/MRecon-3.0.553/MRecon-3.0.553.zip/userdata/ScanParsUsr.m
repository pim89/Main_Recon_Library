classdef ScanParsUsr < ScanPars
    % User Defined Scan Parameter
    properties       
        % Add your own parameter here        
    end
    
    methods
        % Add your own functions here
    end 
end

