classdef CardiacParsUsr < CardiacPars
    % User Defined Cardiac Parameter
    properties       
          
    end
    
    methods
       
    end
end

