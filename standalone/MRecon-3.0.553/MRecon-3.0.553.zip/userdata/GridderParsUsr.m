classdef GridderParsUsr < GridderPars
    % User Defined Gridder Parameter
    properties       
        % Add your own parameter here        
    end
    
    methods
        % Add your own functions here
    end
end

