classdef Parameter2ReadParsUsr < Parameter2ReadPars
    % User Defined Reading Parameter
    properties       
        % Add your own parameter here        
    end
    
    methods
        % Add your own functions here
    end            
end

