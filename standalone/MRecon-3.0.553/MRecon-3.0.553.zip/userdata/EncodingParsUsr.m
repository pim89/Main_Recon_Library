classdef EncodingParsUsr < EncodingPars
    % User Defined Encoding Parameter
    properties       
        % Add your own parameter here        
    end
    
    methods
        % Add your own functions here
    end
end