classdef ReconFlagParsUsr < ReconFlagPars    
    % User Defined Reconstruction Flags
    properties       
        % Add your own parameter here        
    end
    
    methods
        % Add your own functions here
    end
    
end

