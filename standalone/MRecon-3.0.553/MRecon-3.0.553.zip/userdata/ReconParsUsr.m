classdef ReconParsUsr < ReconPars
    % User Defined Scan Parameter
    properties       
        % Add your own parameter here        
    end
    
    methods
        % Add your own functions here
    end 
end

