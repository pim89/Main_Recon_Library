classdef AveragingPars < handle

	properties (SetAccess = public)
		
		FID_BlockSize = {};
		FID_Pattern   = {};
		Dyn_Averaging = false;
		Dyn_BlockSize = {};
		Dyn_Pattern   = {};

	end

end

