classdef SpectroParsDoc
    %UNTITLED Summary of this class goes here
    %   Detailed explanation goes here

	properties
		Downsample = 'Yes'; 	% Enables/disables the use of a downsampling algorithm that is more suitable for spectrocopy data
		Averaging; 				% Holds additional configuration settings to control the averaging process for spectroscopy data
	end
end

